package main

import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/exec"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

// ATSMetrics 定义 ATS 状态接口返回的关键指标
type ATSMetrics struct {
	Global struct {
		// 服务器版本信息
		ServerVersion string `json:"proxy.process.version.server.short"`

		// HTTP 连接指标
		CurrentClientConns string `json:"proxy.process.http.current_client_connections"`
		CurrentServerConns string `json:"proxy.process.http.current_server_connections"`
		TotalClientConns   string `json:"proxy.process.http.total_client_connections"`
		TotalServerConns   string `json:"proxy.process.http.total_server_connections"`

		// 请求和响应统计
		IncomingRequests  string `json:"proxy.process.http.incoming_requests"`
		IncomingResponses string `json:"proxy.process.http.incoming_responses"`

		// 缓存统计
		CacheHits    string `json:"proxy.process.http.cache_hit_fresh"`
		CacheMisses  string `json:"proxy.process.http.cache_miss_cold"`
		CacheLookups string `json:"proxy.process.http.cache_lookups"`

		// 缓存存储状态
		CacheBytesUsed   string `json:"proxy.process.cache.bytes_used"`
		CacheBytesTotal  string `json:"proxy.process.cache.bytes_total"`
		CachePercentFull string `json:"proxy.process.cache.percent_full"`

		// 内存使用
		ProcessMemoryRSS string `json:"proxy.process.traffic_server.memory.rss"`

		// 错误统计
		ConnectionErrors string `json:"proxy.process.http2.connection_errors"`
		StreamErrors     string `json:"proxy.process.http2.stream_errors"`

		// HTTP 状态码统计
		Status2xx string `json:"proxy.process.http.2xx_responses"`
		Status3xx string `json:"proxy.process.http.3xx_responses"`
		Status4xx string `json:"proxy.process.http.4xx_responses"`
		Status5xx string `json:"proxy.process.http.5xx_responses"`

		// 带宽统计
		UserAgentBytes    string `json:"proxy.process.http.user_agent_request_header_total_size"`
		OriginServerBytes string `json:"proxy.process.http.origin_server_response_document_total_size"`

		// 延迟统计
		TotalTransactionTime string `json:"proxy.process.http.transaction_counts.hit_fresh.process"`
		TransactionCount     string `json:"proxy.process.http.completed_requests"`

		// DNS 统计
		DNSLookupSuccess string `json:"proxy.process.dns.lookup_successes"`
		DNSLookupFail    string `json:"proxy.process.dns.lookup_failures"`
		DNSLookupTime    string `json:"proxy.process.dns.lookup_time"`

		// 连接池统计
		CurrentCacheConns string `json:"proxy.process.http.current_cache_connections"`
		PooledServerConns string `json:"proxy.process.http.pooled_server_connections"`

		// SSL/TLS 统计
		SSLHandshakeSuccess string `json:"proxy.process.ssl.total_success_handshake_count_in"`
		SSLHandshakeFailure string `json:"proxy.process.ssl.user_agent_other_errors"`

		// 线程统计
		ThreadCount  string `json:"proxy.process.eventloop.count.10s"`
		ThreadEvents string `json:"proxy.process.eventloop.events.10s"`
	} `json:"global"`
}

// 获取 ATS 指标
func fetchATSMetrics(atsURL string) (*ATSMetrics, error) {
	resp, err := http.Get(atsURL)
	if err != nil {
		return nil, fmt.Errorf("HTTP请求失败: %v", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("读取响应失败: %v", err)
	}

	var metrics ATSMetrics
	if err := json.Unmarshal(body, &metrics); err != nil {
		return nil, fmt.Errorf("解析JSON失败: %v", err)
	}

	return &metrics, nil
}

// 转换为 Prometheus 格式
func metricsToPrometheus(metrics *ATSMetrics) string {
	var sb strings.Builder

	// 当前连接数
	sb.WriteString("# HELP ats_current_client_connections 当前客户端连接数\n")
	sb.WriteString("# TYPE ats_current_client_connections gauge\n")
	val, _ := strconv.ParseInt(metrics.Global.CurrentClientConns, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_current_client_connections %d\n\n", val))

	// 总请求数
	sb.WriteString("# HELP ats_total_requests 总请求数\n")
	sb.WriteString("# TYPE ats_total_requests counter\n")
	val, _ = strconv.ParseInt(metrics.Global.IncomingRequests, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_total_requests %d\n\n", val))

	// 缓存命中数
	sb.WriteString("# HELP ats_cache_hits 缓存命中数\n")
	sb.WriteString("# TYPE ats_cache_hits counter\n")
	val, _ = strconv.ParseInt(metrics.Global.CacheHits, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_cache_hits %d\n\n", val))

	// 缓存未命中数
	sb.WriteString("# HELP ats_cache_misses 缓存未命中数\n")
	sb.WriteString("# TYPE ats_cache_misses counter\n")
	val, _ = strconv.ParseInt(metrics.Global.CacheMisses, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_cache_misses %d\n\n", val))

	// 缓存使用率
	sb.WriteString("# HELP ats_cache_usage_bytes 缓存使用字节数\n")
	sb.WriteString("# TYPE ats_cache_usage_bytes gauge\n")
	val, _ = strconv.ParseInt(metrics.Global.CacheBytesUsed, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_cache_usage_bytes %d\n\n", val))

	// 内存使用
	sb.WriteString("# HELP ats_memory_rss_bytes RSS内存使用字节数\n")
	sb.WriteString("# TYPE ats_memory_rss_bytes gauge\n")
	val, _ = strconv.ParseInt(metrics.Global.ProcessMemoryRSS, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_memory_rss_bytes %d\n\n", val))

	// 错误统计
	sb.WriteString("# HELP ats_connection_errors 连接错误数\n")
	sb.WriteString("# TYPE ats_connection_errors counter\n")
	val, _ = strconv.ParseInt(metrics.Global.ConnectionErrors, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_connection_errors %d\n", val))

	// HTTP 状态码
	sb.WriteString("# HELP ats_http_responses_total HTTP响应状态码统计\n")
	sb.WriteString("# TYPE ats_http_responses_total counter\n")
	val, _ = strconv.ParseInt(metrics.Global.Status2xx, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_http_responses_total{code=\"2xx\"} %d\n", val))
	val, _ = strconv.ParseInt(metrics.Global.Status3xx, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_http_responses_total{code=\"3xx\"} %d\n", val))
	val, _ = strconv.ParseInt(metrics.Global.Status4xx, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_http_responses_total{code=\"4xx\"} %d\n", val))
	val, _ = strconv.ParseInt(metrics.Global.Status5xx, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_http_responses_total{code=\"5xx\"} %d\n\n", val))

	// 带宽统计
	sb.WriteString("# HELP ats_network_bytes_total 总传输字节数\n")
	sb.WriteString("# TYPE ats_network_bytes_total counter\n")
	val, _ = strconv.ParseInt(metrics.Global.UserAgentBytes, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_network_bytes_total{direction=\"in\"} %d\n", val))
	val, _ = strconv.ParseInt(metrics.Global.OriginServerBytes, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_network_bytes_total{direction=\"out\"} %d\n\n", val))

	// 平均响应时间
	if metrics.Global.TransactionCount != "" {
		totalTime, err1 := strconv.ParseFloat(metrics.Global.TotalTransactionTime, 64)
		txCount, err2 := strconv.ParseFloat(metrics.Global.TransactionCount, 64)

		if err1 == nil && err2 == nil && txCount > 0 {
			fmt.Println("totalTime", totalTime)
			fmt.Println("txCount", txCount)
			avgTime := totalTime / txCount
			sb.WriteString("# HELP ats_average_response_time_ms 平均响应时间(毫秒)\n")
			sb.WriteString("# TYPE ats_average_response_time_ms gauge\n")
			sb.WriteString(fmt.Sprintf("ats_average_response_time_ms %.2f\n\n", avgTime))
		}
	}

	// DNS性能
	sb.WriteString("# HELP ats_dns_lookups DNS查询统计\n")
	sb.WriteString("# TYPE ats_dns_lookups counter\n")
	val, _ = strconv.ParseInt(metrics.Global.DNSLookupSuccess, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_dns_lookups{result=\"success\"} %d\n", val))
	val, _ = strconv.ParseInt(metrics.Global.DNSLookupFail, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_dns_lookups{result=\"failure\"} %d\n\n", val))

	// 连接池使用情况
	sb.WriteString("# HELP ats_connection_pool 连接池状态\n")
	sb.WriteString("# TYPE ats_connection_pool gauge\n")
	val, _ = strconv.ParseInt(metrics.Global.CurrentCacheConns, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_connection_pool{type=\"cache\"} %d\n", val))
	val, _ = strconv.ParseInt(metrics.Global.PooledServerConns, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_connection_pool{type=\"server\"} %d\n\n", val))

	// SSL/TLS统计
	sb.WriteString("# HELP ats_ssl_handshakes SSL握手统计\n")
	sb.WriteString("# TYPE ats_ssl_handshakes counter\n")
	val, _ = strconv.ParseInt(metrics.Global.SSLHandshakeSuccess, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_ssl_handshakes{result=\"success\"} %d\n", val))
	val, _ = strconv.ParseInt(metrics.Global.SSLHandshakeFailure, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_ssl_handshakes{result=\"failure\"} %d\n\n", val))

	// 线程统计
	sb.WriteString("# HELP ats_thread_stats 线程统计\n")
	sb.WriteString("# TYPE ats_thread_stats gauge\n")
	val, _ = strconv.ParseInt(metrics.Global.ThreadCount, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_thread_stats{type=\"count\"} %d\n", val))
	val, _ = strconv.ParseInt(metrics.Global.ThreadEvents, 10, 64)
	sb.WriteString(fmt.Sprintf("ats_thread_stats{type=\"events\"} %d\n", val))

	return sb.String()
}

// 认证配置
type AuthConfig struct {
	Username string
	Password string
}

// 设置认证
func requireAuth(auth AuthConfig) gin.HandlerFunc {
	return func(c *gin.Context) {
		// 获取 Basic Auth 认证信息
		username, password, hasAuth := c.Request.BasicAuth()

		// 验证认证信息
		if !hasAuth || username != auth.Username || password != auth.Password {
			c.Header("WWW-Authenticate", "Basic realm=Authorization Required")
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "未授权访问"})
			return
		}

		c.Next()
	}
}

func main() {
	r := gin.Default()

	// 配置认证信息
	auth := AuthConfig{
		Username: "your_username", // 替换为你的用户名
		Password: "your_password", // 替换为你的密码
	}

	r.POST("/update_config", UpdateConfig)     // 更新配置
	r.GET("/request_cert", RequestCertHandler) // 申请证书
	// 设置 ATS 指标抓取端点，使用认证中间件
	r.GET("/metrics", requireAuth(auth), func(c *gin.Context) {
		atsURL := "http://198.12.116.227:8080/_stats"

		// 打印完整的URL
		fmt.Printf("正在请求ATS指标URL: %s\n", atsURL)

		metrics, err := fetchATSMetrics(atsURL)
		if err != nil {
			fmt.Printf("获取指标失败: %v\n", err)
			c.String(http.StatusInternalServerError, fmt.Sprintf("Error fetching metrics: %v", err))
			return
		}

		prometheusMetrics := metricsToPrometheus(metrics)
		c.Header("Content-Type", "text/plain")
		c.String(http.StatusOK, prometheusMetrics)
	})

	fmt.Println("启动服务器在9101端口...")
	r.Run(":9101")
	// 编译
	//GOOS=linux GOARCH=amd64 go build -o ats_exporter main.go

}

// 节点服务器的配置更新接口
func UpdateConfig(c *gin.Context) {
	var configs map[string]string
	if err := c.BindJSON(&configs); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "无效的配置数据"})
		return
	}

	// 更新本地配置文件
	for filename, content := range configs {
		if err := os.WriteFile("/opt/ts/etc/trafficserver/"+filename, []byte(content), 0644); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("更新配置文件 %s 失败: %v", filename, err)})
			return
		}
	}

	// 重新加载 TrafficServer 配置
	if err := exec.Command("/opt/ts/bin/traffic_ctl", "config", "reload").Run(); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "重新加载配置失败"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "配置更新成功"})
}

// 证书申请接口
func RequestCertHandler(c *gin.Context) {
	// 解析请求参数
	domain := c.Query("domain")
	if domain == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "域名参数不能为空"})
		return
	}

	// 检查域名格式
	if !isValidDomain(domain) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "无效的域名格式"})
		return
	}

	// 确保目录存在
	sslDir := "/etc/trafficserver/ssl"
	if err := os.MkdirAll(sslDir, 0755); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "创建SSL目录失败"})
		return
	}

	// 使用 sudo 运行 Certbot
	cmd := exec.Command("sudo", "certbot", "certonly",
		"--webroot",
		"-w", "/var/www",
		"-d", domain,
		"--non-interactive",
		"--agree-tos",
		"--email", "admin@example.com")

	output, err := cmd.CombinedOutput()
	if err != nil {
		log.Printf("为域名 %s 申请证书失败: %v\n输出: %s", domain, err, string(output))
		c.JSON(http.StatusInternalServerError, gin.H{
			"error":   "申请证书失败",
			"details": string(output),
		})
		return
	}

	// 复制证书文件并检查错误
	if err := copyCertificates(domain); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// 重启 ATS
	if err := restartATS(); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "重启ATS失败"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": fmt.Sprintf("域名 %s 的证书已成功申请并应用到ATS", domain)})
}

// 辅助函数
func isValidDomain(domain string) bool {
	// 简单的域名格式检查
	return len(domain) > 0 && len(domain) < 255 && !strings.Contains(domain, " ")
}

func copyCertificates(domain string) error {
	crtSrc := fmt.Sprintf("/etc/letsencrypt/live/%s/fullchain.pem", domain)
	keySrc := fmt.Sprintf("/etc/letsencrypt/live/%s/privkey.pem", domain)
	crtDst := fmt.Sprintf("/opt/ts/ssl/%s.crt", domain)
	keyDst := fmt.Sprintf("/opt/ts/ssl/%s.key", domain)

	// 使用 sudo 复制文件
	if err := exec.Command("sudo", "cp", crtSrc, crtDst).Run(); err != nil {
		return fmt.Errorf("复制证书文件失败: %v", err)
	}

	if err := exec.Command("sudo", "cp", keySrc, keyDst).Run(); err != nil {
		return fmt.Errorf("复制私钥文件失败: %v", err)
	}

	// 设置权限
	if err := exec.Command("sudo", "chown", "nobody:nobody", crtDst, keyDst).Run(); err != nil {
		return fmt.Errorf("设置证书权限失败: %v", err)
	}

	if err := exec.Command("sudo", "chmod", "644", crtDst, keyDst).Run(); err != nil {
		return fmt.Errorf("设置证书权限失败: %v", err)
	}

	return nil
}

func restartATS() error {
	// 使用 sudo 重启服务
	if err := exec.Command("sudo", "systemctl", "restart", "trafficserver").Run(); err != nil {
		return fmt.Errorf("重启ATS失败: %v", err)
	}
	return nil
}

#!/bin/bash

# 设置颜色变量
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# 错误处理
set -e
trap 'echo -e "${RED}错误: 脚本在第 $LINENO 行失败${NC}"' ERR

# 日志函数
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 等待 apt 锁释放
wait_for_apt() {
    local max_attempts=30
    local attempt=1
    while fuser /var/lib/dpkg/lock >/dev/null 2>&1 || fuser /var/lib/apt/lists/lock >/dev/null 2>&1 || fuser /var/lib/dpkg/lock-frontend >/dev/null 2>&1; do
        log_warn "等待包管理器锁释放... (尝试 $attempt/$max_attempts)"
        if [ $attempt -gt $max_attempts ]; then
            log_error "等待超时，退出安装"
            exit 1
        fi
        sleep 10
        attempt=$((attempt + 1))
    done
}

# 1. 系统初始化
init_system() {
    log_info "开始系统初始化..."
    
    # 更新系统
    wait_for_apt
    apt-get update
    
    # 安装基础工具
    log_info "安装基础工具..."
    apt-get install -y curl wget vim htop net-tools sudo ufw tzdata certbot
    
    # 设置时区
    log_info "设置时区为上海..."
    ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
    dpkg-reconfigure -f noninteractive tzdata
    
    # 配置防火墙
    log_info "配置防火墙..."
    yes | ufw enable
    ufw default deny
    ufw allow 22/tcp
    ufw allow 80/tcp   # HTTP
    ufw allow 443/tcp  # HTTPS
    ufw allow 8080/tcp # ATS
    ufw allow 9101/tcp # Metrics
}

# 2. 系统参数优化
optimize_system() {
    log_info "优化系统参数..."
    
    # 设置系统参数
    cat > /etc/sysctl.d/99-ats-custom.conf <<EOF
net.ipv4.ip_forward = 1
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_max_syn_backlog = 8192
net.ipv4.tcp_max_tw_buckets = 5000
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_slow_start_after_idle = 0
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 8192
net.ipv4.tcp_keepalive_time = 600
net.ipv4.tcp_keepalive_intvl = 30
net.ipv4.tcp_keepalive_probes = 3
fs.file-max = 1000000
EOF
    sysctl -p /etc/sysctl.d/99-ats-custom.conf

    # 设置系统限制
    cat > /etc/security/limits.d/99-ats-custom.conf <<EOF
*       soft    nofile  1000000
*       hard    nofile  1000000
*       soft    nproc   1000000
*       hard    nproc   1000000
EOF
}

# 3. 安装 ATS
install_ats() {
    log_info "开始安装 Apache Traffic Server..."
    
    # 安装依赖
    apt-get install -y build-essential libssl-dev libpcre3-dev libcap-dev \
        libhwloc-dev libncurses5-dev libcurl4-openssl-dev flex tcl-dev \
        automake libtool pkg-config graphviz gcc make ninja-build \
        liblzma-dev libpcre2-dev

    # 创建安装目录和SSL目录
    mkdir -p /opt/ts/{bin,etc,ssl}
    
    # 下载和编译 ATS
    cd /tmp
    wget https://dlcdn.apache.org/trafficserver/trafficserver-10.0.3.tar.bz2
    tar xf trafficserver-10.0.3.tar.bz2
    cd trafficserver-10.0.3
    
    # 配置和编译
    ./configure --prefix=/opt/ts
    make -j$(nproc)
    make install
    
    # 创建服务
    cat > /etc/systemd/system/trafficserver.service <<EOF
[Unit]
Description=Apache Traffic Server
After=network.target

[Service]
Type=simple
Environment=TS_ROOT=/opt/ts
ExecStart=/opt/ts/bin/traffic_server
ExecReload=/opt/ts/bin/traffic_ctl config reload
Restart=always
RestartSec=10
LimitNOFILE=1000000
LimitNPROC=1000000

[Install]
WantedBy=multi-user.target
EOF

    # 启动服务
    systemctl daemon-reload
    systemctl enable trafficserver
    systemctl start trafficserver
}

# 4. 配置证书目录和权限
setup_ssl() {
    log_info "配置SSL环境..."
    
    # 创建必要的目录
    mkdir -p /var/www/html
    mkdir -p /opt/ts/ssl
    
    # 设置权限
    chown -R nobody:nobody /opt/ts/ssl
    chmod -R 755 /opt/ts/ssl
    
    # 配置 certbot 自动更新
    systemctl enable certbot.timer
    systemctl start certbot.timer

    # 创建证书续期hook
    mkdir -p /etc/letsencrypt/renewal-hooks/deploy
    cat > /etc/letsencrypt/renewal-hooks/deploy/copy-certs-to-ats.sh <<EOF
#!/bin/bash
for domain in \$(ls /etc/letsencrypt/live); do
    cp /etc/letsencrypt/live/\$domain/fullchain.pem /opt/ts/ssl/\$domain.crt
    cp /etc/letsencrypt/live/\$domain/privkey.pem /opt/ts/ssl/\$domain.key
    chown nobody:nobody /opt/ts/ssl/\$domain.*
    chmod 644 /opt/ts/ssl/\$domain.*
done
systemctl reload trafficserver
EOF
    chmod +x /etc/letsencrypt/renewal-hooks/deploy/copy-certs-to-ats.sh
}

# 主函数
main() {
    log_info "开始安装部署..."
    
    init_system
    optimize_system
    install_ats
    setup_ssl
    
    log_info "安装完成！"
}

# 执行主函数
main "$@"